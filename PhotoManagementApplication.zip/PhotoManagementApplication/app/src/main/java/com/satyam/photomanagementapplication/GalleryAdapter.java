package com.satyam.photomanagementapplication;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.io.File;
import java.util.ArrayList;

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.viewHolder> {
//1
private OnImageClickListener imageClickListener;
//2
    public void setImageClickListener(OnImageClickListener listener) {
        this.imageClickListener = listener;
    }

    private Context context;
    private ArrayList<String> imagesList;

    public GalleryAdapter(Context context, ArrayList<String> imagesList) {
        this.context = context;
        this.imagesList = imagesList;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.gallery_item, null, true);

        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, @SuppressLint("RecyclerView") int position) {

        File imageFile = new File(imagesList.get(position));

        Picasso.get()
                .load(imageFile)
                .fit()
                .centerCrop()
                .into(holder.image);


        holder.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (imageClickListener != null) {
                    imageClickListener.onImageClick(imagesList.get(position));
                }

            }
        });


    }


    @Override
    public int getItemCount() {
        return imagesList.size();
    }


    public class viewHolder extends RecyclerView.ViewHolder{


        private ImageView image;
        public viewHolder(@NonNull View itemView) {
            super(itemView);

            image=itemView.findViewById(R.id.itemImage);

        }
    }

    public interface OnImageClickListener {
        void onImageClick(String imagePath);
    }

}
