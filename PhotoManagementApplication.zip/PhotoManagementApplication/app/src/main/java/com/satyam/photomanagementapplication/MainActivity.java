package com.satyam.photomanagementapplication;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.os.Environment.MEDIA_MOUNTED;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.common.util.concurrent.ListenableFuture;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity implements GalleryAdapter.OnImageClickListener {

    private static final int REQUEST_CAMERA_IMAGE = 100;
    private ListenableFuture<ProcessCameraProvider> cameraProviderFuture;
    static final int PermissionReuestCode = 100;
    Button btnCamera;
    RecyclerView recycler;
    ArrayList<String> image;
    GalleryAdapter adapter;
    GridLayoutManager manager;
    TextView totalImage;
    private ImageCapture imageCapture;

    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCamera=findViewById(R.id.btnCamera);

        recycler=findViewById(R.id.galleryRecycler);
        image=new ArrayList<>();
        adapter=new GalleryAdapter(this, image);
        manager=new GridLayoutManager(this,3);
        totalImage=findViewById(R.id.galleryTotalImage);

        recycler.setAdapter(adapter);
        recycler.setLayoutManager(manager);

        checkPermission();

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent m_intent = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                File file = new File(Environment.getExternalStorageDirectory(), "MyPhoto.jpg");
                Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.satyam.photomanagementapplication.fileProvider", file);
                m_intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri);
                startActivityForResult(m_intent, REQUEST_CAMERA_IMAGE);
            }


        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAMERA_IMAGE && resultCode == RESULT_OK) {
            // File object of camera image
            File file = new File(Environment.getExternalStorageDirectory(), "MyPhoto.jpg");

            // Uri of camera image, retrieve it from the intent data
            Uri uri = Uri.fromFile(file);

            // Do something with the captured image URI, like saving it to the gallery or displaying it in the RecyclerView
            // For example, if you want to add the captured image to the RecyclerView, you can do this:
            image.add(uri.toString());
            recycler.getAdapter().notifyItemInserted(image.size() - 1);
        }
    }


    private void checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        if (result== PackageManager.PERMISSION_GRANTED){
            loadImage();
        }else {
            ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE}, PermissionReuestCode);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length>0){

            boolean accepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (accepted){
                loadImage();
            }else {
                Toast.makeText(this, "You have denied the Permission", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void loadImage() {
        Boolean isSDPresent = android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
        if (isSDPresent){
            final String[] column={
                MediaStore.Images.Media.DATA,  MediaStore.Images.Media._ID
            };
            final String order = MediaStore.Images.Media._ID;
            Cursor cursor= getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, null,null, order);


            int count = cursor.getCount();
            totalImage.setText("Total items: "+ count);




            for (int i=0; i<count;i++){
                cursor.moveToPosition(i);
                int columnIndex = cursor.getColumnIndex(MediaStore.Images.Media.DATA);
                image.add(cursor.getString(columnIndex));
            }

            recycler.getAdapter().notifyDataSetChanged();
            cursor.close();


        }
    }

    @Override
    public void onImageClick(String imagePath) {

        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.image_dialog_layout);

        ImageView imageView = dialog.findViewById(R.id.dialogImageView);
        File imageFile = new File(imagePath);

        Picasso.get()
                .load(imageFile)
                .fit()
                .centerInside()
                .into(imageView);

        dialog.show();
    }
}